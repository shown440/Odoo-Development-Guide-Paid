# Creating systemd service (recent native Ubuntu)
# /lib/systemd/system/odoo.service
sudo systemctl enable odoo.service
sudo systemctl start odoo
sudo systemctl status odoo
sudo systemctl stop odoo
